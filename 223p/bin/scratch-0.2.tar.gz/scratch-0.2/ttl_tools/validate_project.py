import os
import sys
import subprocess
from pathlib import Path
import click
import rdflib
from rich.console import Console
from rich.progress import track
from rich.panel import Panel
from rich.status import Status

from ttl_tools.topquadrant_shacl import infer_and_validate
from ttl_tools.validation2html import print_report

console = Console()

def run_python_file(py_file):
    with console.status(f"[bold blue]Running Python file:[/] {py_file}"):
        result = subprocess.run([sys.executable, str(py_file)])
    if result.returncode != 0:
        console.print(f"[bold red]Error:[/] Python file {py_file} failed.", style="red")
        sys.exit(result.returncode)
    console.print(f"[green]✓ Python file executed successfully: {py_file}[/]")

def run_compile_ttl(ttl_folder):
    with console.status(f"[bold blue]Compiling TTL in:[/] {ttl_folder}"):
        result = subprocess.run(["compile_ttl", str(ttl_folder.resolve())])
    if result.returncode != 0:
        console.print(f"[bold red]Error:[/] compile_ttl failed in {ttl_folder}", style="red")
        sys.exit(result.returncode)
    console.print(f"[green]✓ Compiled TTL in {ttl_folder}[/]")

def run_rdf2html(ttl_folder):
    with console.status(f"[bold blue]Creating HTML from TTL in:[/] {ttl_folder}"):
        result = subprocess.run(["rdf2html", str(ttl_folder.resolve()), "--move"])
    if result.returncode != 0:
        console.print(f"[bold red]Error:[/] rdf2html failed in {ttl_folder}", style="red")
        sys.exit(result.returncode)
    console.print(f"[green]✓ HTML created from TTL in {ttl_folder}[/]")

@click.command()
@click.argument('samples_folder', type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.argument('python_file', type=str)
def main(samples_folder, python_file):
    validate(samples_folder, python_file)

def validate(samples_folder, python_file):
    """
    Run TTL creation, compilation, HTML generation, SHACL validation, and SPARQL queries
    for a given SAMPLES_FOLDER and PYTHON_FILE.
    """
    cwd = Path.cwd()
    samples_folder = (cwd / samples_folder).resolve()
    python_file = (samples_folder / "src" / python_file).resolve()

    if not python_file.exists():
        console.print(f"[bold red]Error:[/] Python file {python_file} does not exist.", style="red")
        sys.exit(1)
    if not samples_folder.exists():
        console.print(f"[bold red]Error:[/] Samples folder {samples_folder} does not exist.", style="red")
        sys.exit(1)

    # Step 1: Run the specified Python file to create TTL files
    run_python_file(python_file)

    # Step 2 & 3: For each ttl folder, run compile_ttl and rdf2html
    for root, dirs, files in os.walk(samples_folder):
        if "ttl" in dirs:
            ttl_folder = Path(root) / "ttl"
            run_compile_ttl(ttl_folder)
            run_rdf2html(ttl_folder)

    # Step 4: Inference and SHACL validation on all TTL files in each ttl folder
    for root, dirs, files in os.walk(samples_folder):
        if "ttl" in dirs:
            ttl_folder = Path(root) / "ttl"
            ttl_files = list(ttl_folder.glob("*.ttl"))
            if not ttl_files:
                continue

            model = rdflib.Graph()
            for ttl_file in track(ttl_files, description=f"[cyan]Loading TTL files for inference/validation in {ttl_folder}"):
                model.parse(ttl_file, format="turtle")

            console.print(Panel(f"Running SHACL inference and validation in [bold]{ttl_folder}[/]", style="cyan"))
            report, valid, inferred = infer_and_validate(model)

            validation_dir = ttl_folder / "validation"
            validation_dir.mkdir(exist_ok=True)
            inferred_ttl = validation_dir / "inferred.ttl"
            report_ttl = validation_dir / "validation_report.ttl"
            inferred.serialize(inferred_ttl, format="turtle")
            report.serialize(report_ttl, format="turtle")

            html_report = validation_dir / "validation_report.html"
            print_report(report, show_info=True, html_path=html_report, title=ttl_folder.name)

            if valid:
                console.print(f"[bold green]✓ Validation PASSED for {ttl_folder}[/]")
            else:
                console.print(f"[bold red]✗ Validation FAILED for {ttl_folder}[/]")
            console.print(f"[blue]Inferred TTL:[/] {inferred_ttl}")
            console.print(f"[blue]Validation report (TTL):[/] {report_ttl}")
            console.print(f"[blue]Validation report (HTML):[/] {html_report}")

    # Step 5: Run SPARQL queries on compiled TTL files in each ttl/validation folder
    for root, dirs, files in os.walk(samples_folder):
        if "sparql" in dirs and "ttl" in dirs:
            rq_folder = Path(root) / "sparql"
            validation_folder = Path(root) / "ttl" / "validation"
            compiled_ttl = None
            for filename in os.scandir(validation_folder):
                if filename.name.endswith("compiled.ttl"):
                    compiled_ttl = Path(filename.path)
                    break
            if compiled_ttl and rq_folder.exists():
                console.print(Panel(f"Running queries in [bold]{rq_folder}[/] on [bold]{compiled_ttl}[/]", style="magenta"))
                result = subprocess.run(
                    ["query_model", str(compiled_ttl), str(rq_folder), "--move"]
                )
                if result.returncode != 0:
                    console.print(f"[bold red]Error:[/] query_model failed for {compiled_ttl} with queries in {rq_folder}", style="red")
                    sys.exit(result.returncode)
                else:
                    console.print(f"[green]✓ Queries executed successfully for {compiled_ttl}[/]")

if __name__ == "__main__":
    main()