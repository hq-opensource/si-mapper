from typing import Dict


from bob.equipment.hvac.valve import (
    TwoWayValve as _BaseTwoWayValve,
    ThreeWayValveMixing as _BaseThreeWayValveMixing,
    ThreeWayValveDiverting as _BaseThreeWayValveDiverting,
)
from bob.core import (
    SCRATCH,
    BoundaryConnectionPoint,
    PropertyReference,
    System,
    logging,
)
from bob.template import template_update
from ..connections.mechanical import MechanicalInletConnectionPoint
from .actuator import ElectricalOnOffActuator, ElectricalProportionalActuator

# logging
_log = logging.getLogger(__name__)

# namespace
_namespace = SCRATCH

class TwoWayValve(_BaseTwoWayValve):
    linkageInlet: MechanicalInletConnectionPoint

class ThreeWayValveMixing(_BaseThreeWayValveMixing):
    linkageInlet: MechanicalInletConnectionPoint

class ThreeWayValveDiverting(_BaseThreeWayValveDiverting):
    linkageInlet: MechanicalInletConnectionPoint

class TwoWayActuatedValve(System):
    """
    This base class allow the creation of a system with a valve and an actuator
    The actuator is at the same layer than the valve, so connections can be made
    via the connection mechanism
    2 versions will be possible : on-off or modulating, depending on the actuator config
    """

    _class_iri = SCRATCH.TwoWayActuatedValveWithActuator
    position: PropertyReference
    command: PropertyReference
    position_feedback: PropertyReference
    is_open: PropertyReference
    is_closed: PropertyReference

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update({}, config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"TwoWayActuatedValve.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)

        self.command = self["valve"]["command"] = self["actuator"]["command"]
        self["is_open"] = self["valve"]["is_open"] = self["actuator"]["is_open"]
        self["is_closed"] = self["valve"]["is_closed"] = self["actuator"]["is_closed"]
        self["actuator"].actuates = self["valve"]
        self.position = self["valve"].position = self["actuator"].position
        self["position_feedback"] = self["actuator"]["position_sensor"].observedProperty
        self | self["valve"].fluidInlet
        self | self["valve"].fluidOutlet


electrical_actuated_proportional_2w_valve_template = {
    "equipment": {
        ("actuator", ElectricalProportionalActuator): {},
        ("valve", TwoWayValve): {},
    },
    "properties": {},
}


class TwoWayActuatedProportionalValve(TwoWayActuatedValve):
    _class_iri = SCRATCH.TwoWayActuatedProportionalValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            electrical_actuated_proportional_2w_valve_template, config
        )
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"TwoWayActuatedProportionalValve.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)
        self | self['actuator'].electricalInlet
        self | self['actuator'].modulationSignal


electrical_actuated_onoff_2w_valve_template = {
    "equipment": {
        ("actuator", ElectricalOnOffActuator): {},
        ("valve", TwoWayValve): {},
    },
    "properties": {},
}


class TwoWayActuatedOnOffValve(TwoWayActuatedValve):
    _class_iri = SCRATCH.TwoWayActuatedOnOffValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(electrical_actuated_onoff_2w_valve_template, config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"TwoWayActuatedOnOffValve.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)


class ThreeWayActuatedValve(System):
    """
    The choice of system brings the actuator at the same layer than the valve
    Connections can be made directly without using mapsTo and duplicating the
    connection points.
    """

    _class_iri = SCRATCH.ThreeWayActuatedValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update({}, config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        self.command = self["valve"]["command"] = self["actuator"]["command"]
        self["is_open"] = self["valve"]["is_open"] = self["actuator"]["is_open"]
        self["is_closed"] = self["valve"]["is_closed"] = self["actuator"]["is_closed"]
        self["actuator"].actuates = self["valve"]
        self["actuator"].linkageOutlet >> self["valve"].linkageInlet
        self["position"] = self["valve"]["position"] = self["actuator"]["position"]
        self["position_feedback"] = self["actuator"]["position_sensor"].observedProperty


class ThreeWayMixingSystem(ThreeWayActuatedValve):
    _class_iri = SCRATCH.ThreeWayMixingSystem

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("valve", ThreeWayValveMixing): {}}}, config
        )
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        self | self["valve"].fluidInletA
        self | self["valve"].fluidInletB
        self | self["valve"].fluidOutlet


class ThreeWayDivertingSystem(ThreeWayActuatedValve):
    _class_iri = SCRATCH.ThreeWayDivertingSystem

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("valve", ThreeWayValveDiverting): {}}}, config
        )
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        self | self["valve"].fluidInlet
        self | self["valve"].fluidOutletA
        self | self["valve"].fluidOutletB


class ThreeWayMixingActuatedProportionalValve(ThreeWayMixingSystem):
    node_type = SCRATCH.ThreeWayMixingActuatedProportionalValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("actuator", ElectricalProportionalActuator): {}}}, config
        )
        kwargs = {**_config.get("params", {}), **kwargs}
        _log.debug(
            f"ThreeWayMixingActuatedProportionalValve.__init__ {_config} {kwargs}"
        )
        super().__init__(_config, **kwargs)


class ThreeWayMixingActuatedOnOffValve(ThreeWayValveMixing):
    _class_iri = SCRATCH.ThreeWayMixingActuatedOnOffValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("actuator", ElectricalOnOffActuator): {}}}, config
        )
        kwargs = {**_config.get("params", {}), **kwargs}
        _log.debug(f"ThreeWayMixingActuatedOnOffValve.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)


class ThreeWayDivertingActuatedProportionalValve(ThreeWayDivertingSystem):
    _class_iri = SCRATCH.ThreeWayDivertingActuatedProportionalValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("actuator", ElectricalProportionalActuator): {}}}, config
        )
        kwargs = {**_config.get("params", {}), **kwargs}
        _log.debug(
            f"ThreeWayDivertingActuatedProportionalValve.__init__ {_config} {kwargs}"
        )
        super().__init__(_config, **kwargs)


class ThreeWayDivertingActuatedOnOffValve(ThreeWayValveDiverting):
    _class_iri = SCRATCH.ThreeWayDivertingActuatedProportionalValve

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            {"equipment": {("actuator", ElectricalOnOffActuator): {}}}, config
        )
        kwargs = {**_config.get("params", {}), **kwargs}
        _log.debug(f"ThreeWayDivertingActuatedOnOffValve.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)
