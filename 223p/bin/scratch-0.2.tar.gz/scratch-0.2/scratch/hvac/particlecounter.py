from typing import Dict

from bob.properties.states import NormalAlarmStatus

from bob.connections.air import AirInletConnectionPoint, AirOutletConnectionPoint
from bob.core import P223, SCRATCH, Equipment
from bob.sensor.particle import (
    CoarseParticulateSensor,
    FineParticulateSensor,
    UltraFineParticulateSensor,
)
from bob.template import template_update, configure_relations

_namespace = SCRATCH


particlecounter_template = {
    "properties": {"alarmStatus": NormalAlarmStatus},
    "sensors": {
        ("label_of_sensor_1", CoarseParticulateSensor): {
            "hasExternalReference": "bacnet://",
            "comment": "Coarse Particles 10.0um or less",
        },
        ("label_of_sensor_2", FineParticulateSensor): {
            "hasExternalReference": "bacnet://",
            "comment": "Fine Particles 2.5um or less",
        },
        ("label_of_sensor_3", UltraFineParticulateSensor): {
            "hasExternalReference": "bacnet://",
            "comment": "Ultra Fine Particles 1.0um or less",
        },
    },
}


class ParticleCounter(Equipment):
    _class_iri = P223.ParticleCounter
    airInlet: AirInletConnectionPoint
    airOutlet: AirOutletConnectionPoint

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(particlecounter_template, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _relations = _config.pop("relations", [])
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)