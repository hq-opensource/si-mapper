from typing import Dict

from bob.properties.electricity import ElectricPowerkW
from bob.properties.states import NormalAlarmStatus

from bob.connections.electricity import (
    Electricity_600VLL_3Ph_60HzInletConnectionPoint,
)
from bob.connections.controlsignal import (
    ModulationSignalInletConnectionPoint,
    OnOffSignalOutletConnectionPoint,
)
from bob.connections.liquid import (
    ChilledWaterInletConnectionPoint,
    ChilledWaterOutletConnectionPoint,
    CondenserInletConnectionPoint,
    CondenserOutletConnectionPoint,
    WaterInletConnectionPoint,
    WaterOutletConnectionPoint,
)
from bob.core import SCRATCH
from scratch import application
from bob.properties import OnOffCommand, OnOffStatus, Percent
from bob.equipment.hvac.chiller import Chiller as BaseChiller
from bob.template import template_update, configure_relations

_namespace = SCRATCH

chiller_template = {
    "cp": {"electricalInlet": Electricity_600VLL_3Ph_60HzInletConnectionPoint},
    "properties": {
        ("kW", ElectricPowerkW): {},
    },
}


class Chiller(BaseChiller, application.Chiller):
    chilledWaterEntering: ChilledWaterInletConnectionPoint
    chilledWaterLeaving: ChilledWaterOutletConnectionPoint
    condenserEntering: CondenserInletConnectionPoint
    condenserLeaving: CondenserOutletConnectionPoint

    # refrigerant
    # manufacturer
    setpointResetInlet: ModulationSignalInletConnectionPoint
    alarmOutlet: OnOffSignalOutletConnectionPoint
    capacityLimitInlet: ModulationSignalInletConnectionPoint

    setpointReset: Percent
    capacityLimit: Percent
    onOffStatus: OnOffStatus
    alarmStatus: NormalAlarmStatus
    onOffCommand: OnOffCommand

    def __init__(self, config: Dict = chiller_template, **kwargs):
        _config = template_update(chiller_template, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _relations = _config.pop("relations", [])
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)
        self.chilledWaterLeaving.paired_to(self.chilledWaterEntering)
        self.condenserLeaving.paired_to(self.condenserEntering)


class AgnosticChiller(BaseChiller, application.Chiller):
    chilledWaterLeaving: WaterOutletConnectionPoint
    chilledWaterEntering: WaterInletConnectionPoint
    condensedWaterLeaving: WaterOutletConnectionPoint
    condensedWaterEntering: WaterInletConnectionPoint

    # refrigerant
    # manufacturer
    setpointResetInlet: ModulationSignalInletConnectionPoint
    alarmOutlet: OnOffSignalOutletConnectionPoint
    capacityLimitInlet: ModulationSignalInletConnectionPoint

    setpointReset: Percent
    capacityLimit: Percent
    onOffStatus: OnOffStatus
    alarmStatus: NormalAlarmStatus
    onOffCommand: OnOffCommand

    def __init__(self, config: Dict = chiller_template, **kwargs):
        _config = template_update(chiller_template, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _relations = _config.pop("relations", [])
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)
