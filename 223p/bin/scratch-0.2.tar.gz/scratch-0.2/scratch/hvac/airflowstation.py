from typing import Dict

from bob.connections.air import AirInletConnectionPoint, AirOutletConnectionPoint
from bob.core import Equipment, P223
from bob.sensor.flow import AirFlowSensor
from bob.template import template_update

_namespace = P223

airflowmonitor_template = {
    "params": {
        "label": "Name Of Equipment",
        "comment": "Description",
    },
    "sensors": {
        ("airflow_sensor", AirFlowSensor): {},
    },
    "properties": {},
}

class AirFlowMonitor(Equipment):
    _class_iri = P223.AirFlowMonitor
    airInlet: AirInletConnectionPoint
    airOutlet: AirOutletConnectionPoint
    flowSensor: AirFlowSensor
    
    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(airflowmonitor_template, config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
