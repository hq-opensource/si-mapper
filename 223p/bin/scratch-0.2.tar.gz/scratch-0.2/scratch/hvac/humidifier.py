from typing import Dict
from bob.core import S223, UNIT
from bob.equipment.hvac.humidifier import ElectricalHumidifier as _BaseElectricalHumidifier
from bob.sensor.humidity import AirHumiditySensor
from bob.sensor.pressure import AirDifferentialStaticPressureSensor
from bob.connections.electricity import (
    Electricity_600VLL_3Ph_60HzInletConnectionPoint,
    Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
)
from bob.connections.controlsignal import (
    ModulationSignalInletConnectionPoint,
    OnOffSignalInletConnectionPoint,
    OnOffSignalOutletConnectionPoint,
)
from bob.connections.liquid import WaterInletConnectionPoint, WaterOutletConnectionPoint, SteamOutletConnectionPoint
from bob.properties import (
    HP,
    RPM,
    Amps,
    ElectricPowerkW,
    PowerFactor,
    Pressure,
)
from bob.template import template_update

humidifier_template = {
    "cp": {"electricalInlet": Electricity_600VLL_3Ph_60HzInletConnectionPoint,
           "startCommand": OnOffSignalInletConnectionPoint,
           "modulationSignal": ModulationSignalInletConnectionPoint,
           "alarm": OnOffSignalOutletConnectionPoint,},
    "properties": {
        ("kW", ElectricPowerkW): {},
    },
    "sensors":{
        ("HHL", AirHumiditySensor): {"hasUnit": UNIT["L-PER-SEC"], "comment": "Humidity High Limit"},
        ("FlowSwitch", AirDifferentialStaticPressureSensor): {"comment": "Air FLow Switch"}
    }
}

class ElectricalHumidifier(_BaseElectricalHumidifier):
    _class_iri = S223.Humidifier
    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(humidifier_template, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}

        super().__init__(_config, **kwargs)