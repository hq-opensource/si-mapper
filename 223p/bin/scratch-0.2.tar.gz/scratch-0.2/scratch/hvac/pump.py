from typing import Dict

from rdflib import URIRef

from scratch.electricity.starter import MotorStarter
from bob.equipment.electricity.vfd import VFD
from bob.equipment.hvac.pump import Pump as BasePump
from bob.properties.ratio import PercentCommand

from bob.connections.electricity import (
    Electricity_600VLL_3Ph_60HzInletConnectionPoint,
    Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
)
from bob.connections.liquid import WaterInletConnectionPoint, WaterOutletConnectionPoint
from bob.core import SCRATCH, S223, UNIT, PropertyReference, logging
from bob.properties import (
    HP,
    RPM,
    Amps,
    ElectricPowerkW,
    PowerFactor,
    Pressure,
)
from bob.template import template_update

# logging
_log = logging.getLogger(__name__)

# namespace
_namespace = SCRATCH

pump_template = {
    "cp": {"electricalInlet": Electricity_600VLL_3Ph_60HzInletConnectionPoint},
    "properties": {
        ("head_pressure", Pressure): {"hasUnit": UNIT.PSI},
        ("amps", Amps): {},
        ("rpm", RPM): {},
        ("hp", HP): {},
        ("kW", ElectricPowerkW): {},
        ("powerFactor", PowerFactor): {},
    },
}


class Pump(BasePump):
    fluidInlet: WaterInletConnectionPoint
    fluidOutlet: WaterOutletConnectionPoint
    onOffStatus: PropertyReference
    onOffCommand: PropertyReference

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(pump_template, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"Fan.__init__ {_config} {kwargs}")

        super().__init__(_config, **kwargs)
        self.fluidOutlet.paired_to(self.fluidInlet)


starter_addon_template = {
    "equipment": {
        ("starter", MotorStarter): {
            "config": {
                "cp": {
                    "electricalInlet": Electricity_600VLL_3Ph_60HzInletConnectionPoint,
                    "electricalOutlet": Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
                }
            },
        }
    },
    "properties": {("speedRatio", PercentCommand): {}},
}


class PumpWithStarter(Pump):
    """
    This pump is composed of a pump, an electrical motor and a starter
    """

    _class_iri: URIRef = S223.Pump

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            bases=[pump_template, starter_addon_template],
            config=config,
        )
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"PumpWithStarter.__init__ {_config} {kwargs}")

        super().__init__(_config, **kwargs)
        self.onOffCommand = self["starter"]["onOffCommand"]
        self.onOffStatus = self["starter"]["starter.current_sensor"].observes
        self["starter"].actuatesProperty = self["speedRatio"]
        self["starter"].electricalOutlet >> self.electricalInlet


VFD_addon_template = {
    "equipment": {("vfd", VFD): {}},
    "properties": {},
}


class PumpWithVFD(Pump):
    """
    This fan is composed of a blower, an electrical motor and a VFD
    """

    _class_iri: URIRef = S223.Pump

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(
            bases=[pump_template, VFD_addon_template],
            config=config,
        )
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"PumpWithVFD.__init__ {_config} {kwargs}")
        super().__init__(_config, **kwargs)
        self.onOffCommand = self["vfd"]["run_command"]
        self.onOffStatus = self["vfd"]["drive_running"]
        self["vfd"].actuatesProperty = self["speedRatio"]
        self["vfd"].electricalOutlet >> self.electricalInlet
