from typing import Dict

from rdflib import URIRef

from bob.properties import PercentCommand
from bob.properties.electricity import Amps, ElectricPowerkW
from bob.connections.air import (
    AirInletConnectionPoint,
    AirOutletConnectionPoint,
)
from bob.connections.electricity import (
    Electricity_600VLL_3Ph_60HzInletConnectionPoint,
    Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
)
from bob.connections.controlsignal import (
    ModulationSignalInletConnectionPoint,
)
from bob.core import SCRATCH, P223, Equipment, System
from bob.equipment.hvac.actuator import Actuator
from bob.equipment.hvac.coil import ElectricalHeatingCoil
from bob.template import template_update, configure_relations

_namespace = SCRATCH

# SCR
SCR_template = {
    "cp": {
        "electricalInlet": Electricity_600VLL_3Ph_60HzInletConnectionPoint,
        "electricalOutlet": Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
        "modulationSignal": ModulationSignalInletConnectionPoint,
    },
    "properties": {
        ("modulation", PercentCommand): {},
        ("amps", Amps): {},
        ("kW", ElectricPowerkW): {},
    },
}


class SCR(Actuator):
    # takes 600V (or 347V) in and use triacs to modulate
    # power given to electrical coil
    # a SCR accept 0-10VDC signal to modulate
    _class_iri: URIRef = P223.SCR

    def __init__(self, config: Dict = SCR_template, **kwargs):
        _config = template_update({}, config=config)
        _relations = _config.pop("relations", {})
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)
        self.electricalOutlet.paired_to(self.electricalInlet)
        self.actuatedby(self.modulationSignal)


ElectricalHeatingCoil_and_SCR_template = {
    "equipment": {
        ("scr", SCR): {
            "comment": "SCR used to modulate the power to the heater",
        },
        ("element", ElectricalHeatingCoil): {
            "comment": "Electrical Heating Coil",
        },
    },
}

class ElectricalHeatingCoilWithSCR(System):
    """
    A Heater and SCR combination.
    The SCR is used to modulate the power to the heater.
    """

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(ElectricalHeatingCoil_and_SCR_template, config=config)
        _relations = _config.pop("relations", {})
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)
        self["scr"].actuates = self["element"]
        self['scr'].electricalOutlet >> self['element'].electricalInlet
        self['scr']['modulation'] @ self['element']['modulation']