from bob.core import BOB, PropertyReference, SCRATCH
from bob.functions import Function
from bob.properties import PercentCommand, Temperature

_namespace = SCRATCH

# WIP : For now, it won't be in hvacspace by default


class IndoorAir(Function):
    # uses_input
    heating: PercentCommand
    cooling: PercentCommand
    # produces_output
    temperture: Temperature
    hasOccupancySensor: PropertyReference
    # What if I need to connect more than 1 ???
    # def __init__(self, **kwargs):
