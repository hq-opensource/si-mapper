import logging
from typing import Dict

from bob.equipment.control.controller import Controller as BaseController
from bob.connections.electricity import Electricity_24VLN_1Ph_60HzInletConnectionPoint
from bob.connections.network import RS485BidirectionalConnectionPoint


from bob.core import SCRATCH
from bob.template import template_update
from bob.properties import Percent, PercentCommand
from bob.template import configure_relations

# logging
_log = logging.getLogger(__name__)

# namespace
_namespace = SCRATCH

controller_template = {
    "cp": {
        "electricalInlet": Electricity_24VLN_1Ph_60HzInletConnectionPoint,
        "bacnet_mstp": RS485BidirectionalConnectionPoint,
    },
    "properties": {},
}


class Controller(BaseController):
    """
    A controller executes function blocks and connect to other Equipment
    through different connection points (AI, AO, BI, BO)
    """

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update({}, config=config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _log.debug(f"Controller.__init__ {_config} {kwargs}")

        super().__init__(_config, **kwargs)


vav_controller_template = {
    "properties": {
        ("damper_command", PercentCommand): {},
        ("damper_position_feedback", Percent): {},
    },
}


class VAVController(Controller):
    """
    A VAV Controller contains an actuator and a position sensor.
    It is meant to be used in a VAV (Terminal Unit) configuration.

    """
    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(vav_controller_template, config)
        kwargs = {**_config.pop("params", {}), **kwargs}
        _relations = _config.pop("relations", [])
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)
