from typing import Dict

from bob.enum import Numerical, ElectricalPhaseIdentifier
from bob.properties.electricity import (
    ElectricApparentEnergy,
    ElectricApparentPower,
    ElectricEnergy,
    ElectricPower,
    ElectricReactiveEnergy,
    ElectricReactivePower,
    Frequency,
    PowerFactor,
    Volts,
)
from bob.sensor.electricity import CurrentSensor, VoltageSensor
from bob.connections.electricity import (
    ElectricalInletConnectionPoint,
    ElectricalOutletConnectionPoint,
)
from bob.functions import Function, FunctionInput, FunctionOutput
from bob.core import SCRATCH, P223, UNIT, Equipment, Node
from bob.template import template_update
from rdflib import URIRef

_namespace = SCRATCH


class EffectivePowerConsumed(Function):
    voltage: FunctionInput
    current: FunctionInput
    effectivePower: FunctionOutput


class ChargingStation(Equipment):
    _class_iri: URIRef = P223.ChargingStation
    _volatile = ("electricalInlet", "electricalOutlet")
    electricalInlet: ElectricalInletConnectionPoint
    electricalOutlet: ElectricalOutletConnectionPoint
