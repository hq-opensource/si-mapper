from typing import Dict

from bob.connections import electricity as elec_cnx
from bob.connections.controlsignal import (
    OnOffSignalInletConnectionPoint,
    OnOffSignalOutletConnectionPoint,
)
from bob.core import SCRATCH, P223, UNIT, PropertyReference, Equipment
from scratch.electricity.switch import CurrentRelay
from bob.properties.electricity import ElectricPower
from bob.properties.states import OnOffCommand
from bob.template import template_update, configure_relations

# namespace
_namespace = SCRATCH

electric_starter_template = {
    "cp": {
        "electricalInlet": elec_cnx.InletConnectionPoint,
        "electricalOutlet": elec_cnx.OutletConnectionPoint,
        "startCommand": OnOffSignalInletConnectionPoint,
        "statusSignal": OnOffSignalOutletConnectionPoint,
    },
    "sensors": {
        ("currentRelay", CurrentRelay): {},
    },
    "properties": {
        # ("actuatesProperty", PercentCommand): {},
        ("onOffCommand", OnOffCommand): {},
        ("powerRating", ElectricPower): {"hasUnit": UNIT["HP_Electric"]},
    },
    "relations": [
        ("self['currentRelay'].dryContact",'mapsTo',"self.statusSignal"),
    ]
}

class MotorStarter(Equipment):
    """
    Motor starter
    This Equipment provides command and status for an electrical
    Equipment like a fan or a pump

    """

    _class_iri = P223.MotorStarter

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(electric_starter_template, config)
        _relations = _config.pop("relations", [])
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)


electric_starter_600V_template = {
    "cp": {
        "electricalInlet": elec_cnx.Electricity_600VLL_3Ph_60HzInletConnectionPoint,
        "electricalOutlet": elec_cnx.Electricity_600VLL_3Ph_60HzOutletConnectionPoint,
        "startCommand": OnOffSignalInletConnectionPoint,
    },
    "sensors": {
        ("currentRelay", CurrentRelay): {},
    },
    "properties": {
        # ("actuatesProperty", PercentCommand): {},
        ("onOffCommand", OnOffCommand): {},
        ("powerRating", ElectricPower): {"hasUnit": UNIT["HP_Electric"]},
    },
}

class MotorStarter_600VLL_3Ph_60Hz(Equipment):
    """
    Motor starter
    This Equipment provides command and status for an electrical
    Equipment like a fan or a pump
    This prototype is a 600V 3phases motor starter that implements
    onOffCommand and onOffStatus properties
    status is given by a current relay that is connected to the electrical outlet, that read
    current using its current sensor.

    """

    _class_iri = SCRATCH.MotorStarter_600VLL_3Ph_60Hz
    outputSignal: OnOffSignalOutletConnectionPoint
    inputSignal: OnOffSignalInletConnectionPoint
    onOffStatus: PropertyReference

    def __init__(self, config: Dict = None, **kwargs):
        _config = template_update(electric_starter_600V_template, config)
        _relations = _config.pop("relations", [])
        kwargs = {**_config.pop("params", {}), **kwargs}
        super().__init__(_config, **kwargs)
        configure_relations(self, _relations)

        if self["currentRelay"]:
            self.onOffStatus = self["currentRelay"]["onOffStatus"]
            self["currentRelay"]["currentSensor"] % self.electricalOutlet
