from bob.core import P223, S223
from bob.connections import (
    BidirectionalConnectionPoint,
    Connection,
    ConnectionPoint,
)
from bob.enum import PowerAndSignal, Signal, Electricity, ProtocolEnum
from bob.properties.network import Kbit_per_seconds

# namespace
_namespace = P223
Electricity.DC15V = Electricity.DC("15V")
PowerAndSignal.SABus = PowerAndSignal("JCI_SABus", _alt_namespace=P223)
PowerAndSignal.SABus.add_constituent(Signal.RS485)
PowerAndSignal.SABus.add_constituent(Electricity.DC15V)

# === Networks - SABus (RS485+15VDC) ===


class SABusConnection(Connection):
    hasMedium = PowerAndSignal.SABus
    _class_iri = S223.Connection


class SABusConnectionPoint(ConnectionPoint):
    _attr_uriref = {
        "hasProtocol": P223.hasProtocol,
        "data_rate": P223.data_rate,
    }
    hasMedium = PowerAndSignal.SABus
    hasProtocol: ProtocolEnum
    data_rate: Kbit_per_seconds


class SABusBidirectionalConnectionPoint(
    BidirectionalConnectionPoint, SABusConnectionPoint
):
    _class_iri = S223.BidirectionalConnectionPoint
