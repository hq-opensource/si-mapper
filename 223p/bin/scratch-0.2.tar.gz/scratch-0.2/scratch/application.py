from rdflib import URIRef

from bob.core import Node, SCRATCH

_namespace = SCRATCH


class AirHandlingUnit(Node):
    _class_iri: URIRef = SCRATCH["Application-AirHandlingUnit"]


class Boiler(Node):
    _class_iri: URIRef = SCRATCH["Application-Boiler"]


class Chiller(Node):
    _class_iri: URIRef = SCRATCH["Application-Chiller"]


class CoolingTower(Node):
    _class_iri: URIRef = SCRATCH["Application-CoolingTower"]


class FumeHood(Node):
    _class_iri: URIRef = SCRATCH["Application-FumeHood"]


class Furnace(Node):
    _class_iri: URIRef = SCRATCH["Application-Furnace"]


class HeatExchanger(Node):
    _class_iri: URIRef = SCRATCH["Application-HeatExchanger"]


class HeatPump(Node):
    _class_iri: URIRef = SCRATCH["Application-HeatPump"]


class HotWaterHeater(Node):
    _class_iri: URIRef = SCRATCH["Application-HotWaterHeater"]


class AirToAirHeatPump(HeatPump):
    _class_iri: URIRef = SCRATCH["HeatPump-AirToAirHeatPump"]


class GroundToAirHeatPump(HeatPump):
    _class_iri: URIRef = SCRATCH["HeatPump-GroundToAirHeatPump"]


class WaterToAirHeatPump(HeatPump):
    _class_iri: URIRef = SCRATCH["HeatPump-WaterToAirHeatPump"]


class WaterToWaterHeatPump(HeatPump):
    _class_iri: URIRef = SCRATCH["HeatPump-WaterToWaterHeatPump"]


class TerminalUnit(Node):
    _class_iri: URIRef = SCRATCH["Application-TerminalUnit"]


class FanCoilUnit(TerminalUnit):
    _class_iri: URIRef = SCRATCH["TerminalUnitApplication-FanCoilUnit"]


class FanPoweredTerminal(TerminalUnit):
    _class_iri: URIRef = SCRATCH["TerminalUnitApplication-FanPoweredTerminal"]


class SingleDuctTerminal(TerminalUnit):
    _class_iri: URIRef = SCRATCH["TerminalUnitApplication-SingleDuctTerminal"]


class DualDuctTerminal(TerminalUnit):
    _class_iri: URIRef = SCRATCH["TerminalUnitApplication-DualDuctTerminal"]


class ElectricalDistribution(Node):
    _class_iri: URIRef = SCRATCH["Application-ElectricalDistribution"]


class ElectricalPanel(ElectricalDistribution):
    _class_iri: URIRef = SCRATCH["ElectricalDistribution-ElectricalPanel"]
