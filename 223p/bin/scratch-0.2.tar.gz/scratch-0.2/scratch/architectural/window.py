from bob.connections.air import AirBidirectionalConnectionPoint
from bob.core import SCRATCH, PropertyReference
from bob.equipment.architectural.window import Window as BaseWindow

_namespace = SCRATCH

class Window(BaseWindow):
    opening: AirBidirectionalConnectionPoint

    # Those will come from something else, but be accessible from here.
    openCloseStatus: PropertyReference
    openCloseCommand: PropertyReference
    shadeStatus: PropertyReference
    shadeCommand: PropertyReference
    breakDetection: PropertyReference
