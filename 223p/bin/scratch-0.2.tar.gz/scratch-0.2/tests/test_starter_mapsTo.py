from pathlib import Path


from scratch.assemblage import create_data_and_schema_ttl, model_namespace
from bob.core import (
    bind_model_namespace,
    dump
)
from scratch.header import sample_header
from scratch.hvac.vav import VAV, vav_withelectricreheat_template
from scratch.electricity.starter import MotorStarter

from header import ttl_test_header
model_name, global_ns = model_namespace(__file__)
_namespace = bind_model_namespace(model_name, f"urn:{global_ns}:{model_name}/")



def test_starter():
    

    _folder = Path(__file__).parent / 'ttl'
    s = MotorStarter(label="Motor starter")
    #s['currentRelay'].dryContact.maps_to(s.statusSignal)
    assert s['currentRelay'].dryContact.mapsTo == s.statusSignal 
    dump(filename=f"tests/ttl/{model_name}.ttl", header=ttl_test_header(model_name))
