from pathlib import Path


from scratch.assemblage import create_data_and_schema_ttl, model_namespace
from bob.core import (
    bind_model_namespace,
)
from scratch.header import sample_header
from scratch.hvac.vav import VAV, vav_withelectricreheat_template

model_name, global_ns = model_namespace(__file__)
_namespace = bind_model_namespace(model_name, f"urn:{global_ns}:{model_name}/")



def test_vav():
    v = VAV(config=vav_withelectricreheat_template, label="VAV with Electrical Reheat")

    _folder = Path(__file__).parent
    create_data_and_schema_ttl(model_name, _folder, header=sample_header(model_name))

    _schema_file = _folder / "test_scratch_vav.schema.ttl"
    _data_file = _folder / "test_scratch_vav.data.ttl"
    print(_data_file)
    assert _schema_file.exists()
    assert _data_file.exists()