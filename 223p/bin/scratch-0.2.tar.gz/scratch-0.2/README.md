# si-modeler

Using si-builder (bob) templating mechanism, si-modeler presents extensions of basic S223 classes and add features, properties building enhanced classes. It includes sample models and tools that can be used to browse, apply infererence and validation